﻿//Modify the previous application to print your name.
//Ensure you have named the application well (e.g. “PrintMyName”).
using System;


namespace PrintYourName
{
    class PrintMyName
    {
        static void Main()
        {
            Console.WriteLine("My name is Rambo");
        }
    }
}

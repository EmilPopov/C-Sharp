﻿
//Print First and Last Name
using System;


namespace PrintFirstAndLastName
{
    class PrintMyNames
    {
        static void Main()
        {
            Console.WriteLine("Mitko");
            Console.WriteLine("Berbatov");
        }
    }
}

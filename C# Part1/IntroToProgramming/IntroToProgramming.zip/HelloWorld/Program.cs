﻿//Creeate, compile and run a “Hello C#” console application.
//Ensure you have named the application well (e.g. “”HelloCSharp”).
using System;


namespace HelloWorld
{
    class HelloCSharp
    {
        static void Main()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Hello C#");
        }
    }
}

﻿//Write a program that prints the first 10 members of the sequence: 2, -3, 4, -5, 6, -7, ...
using System;


namespace PrintASequence
{
    class PrintThisSequence
    {
        static void Main()
        {
            Console.WriteLine("2,-3,4,-5,6,-7,8,-9,10,-11");
        }
    }
}

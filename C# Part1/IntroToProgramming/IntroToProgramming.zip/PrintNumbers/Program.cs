﻿//Write a program to print the numbers 1, 101 and 1001, each at a separate line.
//Name the program correctly.
using System;


namespace PrintNumbers
{
    class PrintNum
    {
        static void Main()
        {
            Console.WriteLine("1");
            Console.WriteLine("101");
            Console.WriteLine("1001");
        }
    }
}

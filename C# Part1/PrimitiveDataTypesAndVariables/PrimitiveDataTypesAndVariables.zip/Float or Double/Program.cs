﻿//Which of the following values can be assigned to a variable of type float and which to a variable of type double: 
//34.567839023, 12.345, 8923.1234857, 3456.091?
using System;

namespace Float_or_Double
{
    class Program
    {
        static void Main()
        {
            double firstNum = 34.567839023;
            float secondNum = 12.345F;
            float thirdNum = 8923.1234857F;
            float fourNum = 3456.091F;
        }
    }
}

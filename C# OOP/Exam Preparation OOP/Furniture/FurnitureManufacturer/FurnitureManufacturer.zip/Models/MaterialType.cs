﻿namespace FurnitureManufacturer.Models
{
    public enum MaterialType
    {
        Wooden,
        Leather,
        Plastic
    }
}
